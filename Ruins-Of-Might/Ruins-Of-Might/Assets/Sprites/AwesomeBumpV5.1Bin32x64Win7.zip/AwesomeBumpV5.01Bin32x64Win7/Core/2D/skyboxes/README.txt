You can ADD here your own images. Make sure your images have names: 
negx.jpg, negy.jpg, negz.jpg, posx.jpg, posx.jpg, posy.jpg, posz.jpg
You need to restart the program to update the list of enviromental maps.
