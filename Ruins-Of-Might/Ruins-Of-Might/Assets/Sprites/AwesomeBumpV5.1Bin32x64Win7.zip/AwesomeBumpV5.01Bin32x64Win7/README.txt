=======================================================
= 					WINDOWS users					  =
=======================================================
To run the program on Win7/8 etc:
	1.) Double click exe file.
	2.) enjoy!	

					
=======================================================
= 					LINUX users						  =
=======================================================
To run the program eg. Ubuntu:
	1.) Open terminal in program location.
	2.) Run program with command:
	./RunAwesomeBump.sh
	3.) enjoy!
	
=======================================================
= 					OSX users						  =
=======================================================
To run the program OSX system:
	1.) I have no idea, but if you know please let me know
	how to do it.
	2.) If you managed to build binaries for OSX please send 
	them to me, I will put them on the GitHub repository, such
	that everyone will have access to it.

=======================================================
= 				BUILDING FROM SOURCE				  =
=======================================================	
To build AwesomeBump from source:
	1.) See the GitHub page: https://github.com/kmkolasinski/AwesomeBump	
	2.) Basically you need to know how to build Qt project. Look for 
	this on the internet, for sure, there are plenty of tutorials about this.
	3.) Since 5.0 version AB needs QtnProperty project located in the Source/utils folder.

	
=======================================================
= 					FAQ (for everyone)				  =
=======================================================
In case of PROBLEMS:
	a) See the log.txt file and check its content.
	b) Check supported openGL version (it must be greater than 3.3) (first lines of log.txt file)
	c) Search for the problem on the internet: (e.g here: http://blenderartists.org/forum/showthread.php?364529-AwesomeBump-A-free-alternative-to-CrazyBump)
	d) Check again if there is no answer to your problem somewhere on the internet.
	e) Are you sure you checked everywhere?
	f) Ask me if you have problem: awesomebump.help@gmail.com
	g) Use github issues history to look for possible solution to your problem.
	

